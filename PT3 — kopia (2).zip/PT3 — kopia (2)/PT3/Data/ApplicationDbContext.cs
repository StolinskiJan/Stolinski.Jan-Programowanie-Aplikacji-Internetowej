﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PT3.Models;

namespace PT3.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<PT3.Models.TaskType> TaskType { get; set; } = default!;
        public DbSet<PT3.Models.WorkSession> WorkSession { get; set; } = default!;
        public DbSet<PT3.Models.Task> Task { get; set; } = default!;
    }
}
