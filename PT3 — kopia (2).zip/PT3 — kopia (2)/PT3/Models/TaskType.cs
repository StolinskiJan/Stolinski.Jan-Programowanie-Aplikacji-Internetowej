﻿using System.ComponentModel.DataAnnotations;

namespace PT3.Models
{
    public class TaskType
    {
        public int Id { get; set; }
        [Display(Name = "Nazwa Pracy")]
        public string Name { get; set; }
    }
}
