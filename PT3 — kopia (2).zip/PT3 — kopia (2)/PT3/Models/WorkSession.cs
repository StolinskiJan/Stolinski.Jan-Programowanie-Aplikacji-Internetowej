﻿using System.ComponentModel.DataAnnotations;

namespace PT3.Models
{
    public class WorkSession
    {
        public int Id { get; set; }
        [Display(Name = "Data rozpoczęcia")]
        public DateTime Start { get; set; }
        [Display(Name = "Data zakończenia")]
        public DateTime End { get; set; }
    }
}
