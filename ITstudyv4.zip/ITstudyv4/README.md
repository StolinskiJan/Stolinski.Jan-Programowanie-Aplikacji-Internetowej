# ITstudy

<h1>Instrukcja uruchomienia projektu</h1>
  <h4>Baza danych:</h4>
    <li>Zainstalowanie PostgreSQL</li> 
    <li>Zaimportowanie naszej bazy danych</li>
    <li>Sprawdzenie czy Istnieje użytkownik “postgres” w postgresie o haśle “postgres” (standardowe hasło)</li>
    <li>Upewnienie się że Port postgresa jest prawidłowy - domyślnie w projekcie to 5432, można zmienić </li>
